"""
Lab2.py - Resumen mínimo con pandas.DataFrame.describe()

Este script carga un CSV (o extrae un ZIP que contiene CSVs), aplica
exclusivamente `df.describe(include='all')` para resumir el dataset y
muestra el resultado por consola. Opcionalmente guarda el resumen en
`describe.csv` con la opción `--save`.

Uso:
  python Lab2.py --dataset archive.zip --save

"""

import sys
import argparse
import os
import zipfile
import tempfile
import glob

try:
	import pandas as pd
	import numpy as np
except ImportError:
	print("pandas no está instalado. Instálalo con: pip install pandas")
	sys.exit(1)


def find_csv_in_zip(zip_path):
	tmp = tempfile.mkdtemp(prefix='lab2_')
	with zipfile.ZipFile(zip_path, 'r') as z:
		z.extractall(tmp)
	csvs = glob.glob(os.path.join(tmp, '**', '*.csv'), recursive=True)
	return csvs[0] if csvs else None


def main():
	parser = argparse.ArgumentParser(description='Resumen del dataset con pandas.describe()')
	# --dataset: ruta al archivo .zip o .csv que contiene el dataset
	parser.add_argument('--dataset', type=str, default='archive.zip', help='Ruta a un CSV o ZIP que contenga el dataset')
	# --save: si se pasa, guardamos el resumen en describe.csv
	parser.add_argument('--save', action='store_true', help='Guardar el resumen en describe.csv')
	args = parser.parse_args()

	path = args.dataset
	if not os.path.exists(path):
		print(f"No se encontró el archivo especificado: {path}")
		sys.exit(1)

	if zipfile.is_zipfile(path):
		csv_file = find_csv_in_zip(path)
		if not csv_file:
			print('No se encontraron CSVs dentro del ZIP.')
			sys.exit(1)
	elif path.lower().endswith('.csv'):
		csv_file = path
	else:
		print('El archivo proporcionado debe ser un .zip o un .csv')
		sys.exit(1)

	print(f"Usando CSV: {csv_file}\n")
	df = pd.read_csv(csv_file)


	# df.describe() que resume las columnas numéricas (mean, std, percentiles).
	# Además opcionalmente mostramos un resumen separado para columnas categóricas.
	summary = df.describe()
	print(summary)

	# Resumen categórico separado 
	cat_summary = df.describe(include=['object', 'category'])
	print('\n--- Resumen categórico (separado) ---')
	print(cat_summary)

	# identificar tipos de datos y sugerir análisis
	print('\n--- Tipos de datos por columna (dtypes) ---')
	print(df.dtypes)
	print('\nSugerencias de análisis según tipo:')
	print('- numérico: histogramas, boxplot, outliers, correlación, regresión')
	print('- categórico (object/category): tablas de frecuencia (value_counts), chi-cuadrado, barras')
	print('- booleano: conteos True/False, proporciones')
	print('- datetime: series temporales, tendencias, resample/rolling')

	# Mostrar primeros y últimos registros para detectar tendencias
	print('\n--- Primeras filas (head) ---')
	print(df.head())

	print('\n--- Últimas filas (tail) ---')
	print(df.tail())

	# Ordenar resultados para ver qué categorías destacan más/menos
	print('\n--- Ordenamiento de categorías (groupby + sort_values) ---')
	cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
	if cat_cols:
		for c in cat_cols:
			grouped = df.groupby(c).size().reset_index(name='count')
			# ordenar descendente para ver las categorías más frecuentes
			desc = grouped.sort_values(by='count', ascending=False)
			asc = grouped.sort_values(by='count', ascending=True)
			print(f"\nColumna categórica: {c}")
			print('Top (más frecuentes):')
			print(desc.head())
			print('\nBottom (menos frecuentes):')
			print(asc.head())
	else:
		print('No se encontraron columnas categóricas para ordenar.')

	# Seleccionamos explícitamente la columna 'charges' para los cálculos de medidas
	# El requisito del usuario es calcular las medidas solo sobre 'charges'.
	print('\n--- Cálculo de medidas para la columna numérica \"charges\" ---')
	if 'charges' in df.columns:
		# Convertimos la columna a numérica (por si hubiera strings) y eliminamos NaN
		series = pd.to_numeric(df['charges'], errors='coerce').dropna().astype(float)
		# Calculamos las medidas solicitadas usando NumPy
		mean_val = np.mean(series)
		median_val = np.median(series)
		std_val = np.std(series, ddof=0)
		print('Columna seleccionada: charges')
		print(f' - Media (np.mean): {mean_val}')
		print(f' - Mediana (np.median): {median_val}')
		print(f' - Desviación estándar (np.std): {std_val}')
	else:
		print("La columna 'charges' no se encontró en el dataset.")

	if args.save:
		summary.to_csv('describe.csv')
		print('\nResumen guardado en describe.csv')


if __name__ == '__main__':
	main()

